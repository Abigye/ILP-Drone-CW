package uk.ac.ed.inf.aqmaps;

public class AirQualityData{
	
	public String location;		// holds location (what3words) of a sensor
	public float battery;		// holds the battery level of a sensor
	public String reading;		// holds the air quality reading 

}
